// Click "Download App" with the mouse and the QR code will appear. Click again and it will disappear
var ER = document.getElementById('ER')
var code = document.getElementById('code')
var flag = 0
ER.onclick = function() {
    if (flag == 0 ) {
        code.style.display = 'block'
        flag = 1
    } else {
        code.style.display = 'none'
        flag = 0
    } 
}
// Jump to the desired position smoothly
var scroll = new SmoothScroll('a[href*="#"]', {
	speed: 1500,
	speedAsDuration: true
});
var learn = document.getElementById("learnmore")
learn.onclick = function() {
    alert("HAVE A GOOD DAY!🦈🦈🦈")
}