var eye = document.getElementById('eye')
var psw = document.getElementById('psw')
var flag = 0
// Clicking on the small eye causes the character to hide and appear again
eye.onclick = function() {
    if(flag == 0) {
        psw.type =  'text'
        flag = 1
        eye.src = "images/open.png"
    }else {
        psw.type = 'password'
        flag = 0
        eye.src = "images/close.png"
    }
}
// Set the anchor point
var country = document.getElementById('country')
country.onfocus = function() {
    if(this.value ==='where are you from' ) {
        this.value = ''
    }
    this.style.color = '#333'
}
country.onblur = function() {
    if(this.value === '') {
        this.value = 'where are you from';
    }
    this.style.color = '#999'
}

var phone = document.getElementById('phone')
phone.onfocus = function() {
    if(this.value ==='phone number' ) {
        this.value = ''
    }
    this.style.color = '#333'
}
phone.onblur = function() {
    if(this.value === '') {
        this.value = 'phone number';
    }
    this.style.color = '#999'
}

var call = document.getElementById('call')
call.onfocus = function() {
    if(this.value ==='your name' ) {
        this.value = ''
    }
    this.style.color = '#333'
}
call.onblur = function() {
    if(this.value === '') {
        this.value = 'your name';
    }
    this.style.color = '#999'
}