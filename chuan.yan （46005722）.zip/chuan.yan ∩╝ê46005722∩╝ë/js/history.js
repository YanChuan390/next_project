// Picture scroll
var marqueeLeft = function (el, step) {
    var run  = true,
        wrap = el.find('.wrap'),
        ul   = wrap.find('ul'),
        i    = 0,
        width= ul.outerWidth(true);
    wrap.css('width', width * 3 + 'px');
    ul.clone().appendTo(wrap);
    var timer = setTimeout(function fn() {
        if (run) {
            if (i < width) {
                i++;
            } else {
                i = 0;
            }
            el.scrollLeft(i);
        }
        timer = setTimeout(fn, step);
    }, step);
    el.hover(function(){
        run = false;
    },function(){
        run = true;
    });
};
marqueeLeft($('#marquee'), 15);

// Click on the image to switch the background color
var body = document.body;
[].forEach.call(document.querySelectorAll('img'), function (img) {
    img.onclick = function () {
        var src = this.getAttribute('src');
        document.body.style.backgroundImage = 'url('+src+')';
    }
})