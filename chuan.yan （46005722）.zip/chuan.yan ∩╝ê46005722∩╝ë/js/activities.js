// When it is past twelve o 'clock, the background image will change
var date = new Date()
var h = date.getHours()
if(h<12) {
    document.body.style.backgroundImage = 'url(images/bg_activities1.jpg)'
}else {
    document.body.style.backgroundImage = 'url(images/bg_activities2.jpg)'
}
// The picture is automatically moved to the specified position
$(function() {
    //$('.logo').click(function() {
        $('.picturea img').animate({
            left:1150,
            top:200,
            width:200,
            height:300,
            opacity:.8
        },1000);
        $('.picturea img').click(function() {
            $('.jellyfish').fadeIn()
        });
        $('.pictureb img').animate({
            left:800,
            top:200,
            width:200,
            height:300,
            opacity:.8
        },1000);
        $('.pictureb img').click(function() {
            $('.love').fadeIn()
        });
        $('.picturec img').animate({
            left:450,
            top:200,
            width:200,
            height:300,
            opacity:.8
        },1000);
        $('.picturec img').click(function() {
            $('.mermaid').fadeIn()
        });
        $('.pictured img').animate({
            left:100,
            top:200,
            width:200,
            height:300,
            opacity:.8
        },1000);
        $('.pictured img').click(function() {
            $('.sky').fadeIn()
        });
    //})
});