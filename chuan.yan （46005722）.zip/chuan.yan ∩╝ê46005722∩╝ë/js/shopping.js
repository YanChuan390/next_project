// Click on the text to bring up the picture
[].forEach.call(document.querySelectorAll('.button'), function (btn) {
    var img = btn.parentElement.querySelector('img');
    img.addEventListener("transitionend", function () {
        img.classList.remove('scale');
    });
    btn.onclick = function () {
        img.classList.add('scale');
    };
});